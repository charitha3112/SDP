package com.servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
@WebServlet("/login")
public class Loginservlet  extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String em=req.getParameter("email");
			String ps=req.getParameter("password");
			if("admin@gmail.com"equals(em) && "admin@121".equals(ps)) {
				u.setRole("admin");
				resp.sendRedirect("admin.jsp");
			}
			else {
				
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
